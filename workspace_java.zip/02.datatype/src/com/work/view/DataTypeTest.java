package com.work.view;

public class DataTypeTest {

	public static void main(String[] args) {
		// 시작메서드 내부 선언 변수 : 지역변수
		// 지역변수 선언 방법 및 값할당 방법 : 타입 변수명 = 초기값;
		
		// 같은타입(할당)
		int data1 = 10;
		
		// 큰타입 : 자동형변환(할당)
		long data2 = data1;
		
		// 다른 타입 : 컴파일 오류
		//int data3 = 5.5;
		
		// 명시적 형변환
		int data4 = (int)5.5;	// int = 5 => 소수이하 자리수는 버림처리
		
		System.out.println(data1);
		System.out.println(data2);
		System.out.println(data4);
		
		String s1 = "a";
		char s2 = 'b';
		
		// 다른타입 컴파일 오류 : String 객체형 = 단일문자기본형
		//String s3 = s2;
		
		// 다른타입, 작은타입 이므로 컴파일 오류 발생
		//float f1 = 5.7;
		
		// 명시적 형변환
		float f2 = (float)5.7;
		float f3 = 5.7F;
		
		
	}

}
