package com.work.exception;

/** 사용자 정의 예외 클래스 
 * -- 규칙 :
 * 1. extends Exception
 * 2. super("예외메세지문자열");
 * 
 */
public class UserException extends Exception {

	/**
	 * 기본 생성자
	 */
	public UserException() {
		super("사용자 정의한 예외메세지입니다.");
	}

	/**
	 * 아규먼트로 전달방은 예외메세지 초기화 생성자 
	 * @param message 예외메세지
	 */
	public UserException(String message) {
		super(message);
	}

}


