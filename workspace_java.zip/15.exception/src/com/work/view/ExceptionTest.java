package com.work.view;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ExceptionTest {
	
	// 명시적 예외처리 : 개발자가 직접 예외처리
	public static void main(String[] args) {
		// 친구 5명의 이름정보를 갖는 배열 선언, 생성, 초기화 동시 수행하는 코드를 작성하세요
		String[] names = {"홍길동", "강감찬", "이순신", "김유신", "유관순"};
		
		// 친구 이름정보를 출력하는 10번 반복
		for (int index = 0; index < 10; index++) {
			try {
				System.out.println(names[index]);	// 배열요소 접근시에 오류 발생 가능한 수행문
			} catch(ArrayIndexOutOfBoundsException e) {
				String error = e.getMessage();	// 예외메세지 가져오기
				System.out.println("[예외메세지] " + error);
				e.printStackTrace();	// 예외발생한 사항을 트래킹해서 콘솔창에 출력 : 개발시에 디버그정보 사용
				
				// 반복분 빠져나가기
				break;
				
				// 예외처리 : 프로그램 종료 => 메서드 호출순간 프로그램 강제종료 => finally 수행되지 않음
				//System.exit(0);
			} finally {
				System.out.println("[반드시 수행되야 하는 수행문입니다.]");
			}
		}
		
		System.out.println("프로그램을 정상 종료합니다.");
	}
	
	
	
	// 예외처리를 직접 처리
	public static void main3(String[] args) {
		try {
			FileReader in = new FileReader("userlist.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	// 예외 전가 시키는 방법으로 예외처리
	public static void main2(String[] args) throws FileNotFoundException {
		FileReader in = new FileReader("userlist.txt");
	}
	
	public static void main1(String[] args) {
		// 친구 5명의 이름정보를 갖는 배열 선언, 생성, 초기화 동시 수행하는 코드를 작성하세요
		String[] names = {"홍길동", "강감찬", "이순신", "김유신", "유관순"};
		
		// 친구 이름정보를 출력하는 10번 반복
		for (int index = 0; index < 10; index++) {
			System.out.println(names[index]);
		}
		
		System.out.println("프로그램을 정상 종료합니다.");
	}

}
