package com.work.view;

import java.io.IOException;
import java.sql.SQLException;

import com.work.exception.UserException;

public class UserExceptionTest {

	public static void main(String[] args) {
		UserExceptionTest test = new UserExceptionTest();
		
		try {
			test.doA(90);
			//test.doA(190);
		} catch(UserException e) {
			String errorMessage = e.getMessage();
			System.out.println(errorMessage);
		}
		
		//test.doB("hello");
		try {
			test.doB(null);
		} catch(NullPointerException e) {
			System.out.println(e.getMessage());
		} catch(IOException e) {
			System.out.println(e.getMessage());
		} catch(Exception e) {	// 다중 캐치시에 super 예외가 앞에서 체킹하지 않은 남은 모든 예외를 공통처리
			System.out.println(e.getMessage());
		}
		
		System.out.println("\n프로그램 정상종료되었습니다.");
	}

	// 아규먼트로 정수 숫자를 받아서 출력하는 메서드 : 
	// 메서드명 :  + doA(int) : void
	// 아규먼트로 전달받은 숫자가 100을 초과하면 사용자 예외를 발생시킴
	// doA() 메서드 호출하는 사용자에게 예외처리를 전가시킴
	public void doA(int no) throws UserException {
		if (no > 100) {
			// 사용자 예외를 명시적으로 발생시킴
			//throw new UserException();
			throw new UserException("[사용자예외] 아규먼트는 정수 100이하로 입력하시기 바랍니다.");
		}
		System.out.println(no);
	}
	
	
	// 아규먼트로 문자열을 받아서 출력하는 메서드
	// 메서드명 : + doB(String) : void
	// 개발시에 예외처리가 올바른지 검증하기위해 명시적으로 예외 발생시킴
	// data가 null 여부 검증 : NullPointerException
	public void doB(String data) throws IOException, SQLException {
		if (data == null) {
			//throw new NullPointerException();
			//throw new NullPointerException("[예외] 객체를 생성하지 않아서 사용할 수 없습니다.");
			
			//throw new NumberFormatException("문자형식의 문자를 숫자타입으로 형변환 할 수 없습니다.");
			
			//throw new IOException("[오류] 입출력 예외가 발생했습니다.");
			throw new SQLException("[오류] 데이터베이스 예외가 발생했습니다.");
		}
		
		System.out.println(data);
	}
}
















