package com.abstract_test;

public class AbstractTest {

	public static void main(String[] args) {
		//Pet pet = new Pet();	// 오류 : 추상클래스는 직접 객체생성 불가
		Cat cat = new Cat();
		cat.name = "냐옹이";
		cat.speak();
		cat.song();
		System.out.println(cat.name);
		System.out.println();
		
		Dog dog = new Dog();
		dog.name = "멍멍이";
		dog.speak();
		dog.song();
		System.out.println(dog.name);
	}
}

// 모든 애완동물에 대한 일반화시킨 부모클래스 : 추상클래스
abstract class Pet {
	public String name;
	
	public abstract void speak();
	
	public void song() {
		System.out.println("라라라라라~~~");
	}
}

// Pet 추상(부모)클래스를 상속받은 자식클래스 : 
class Cat extends Pet {
	public void speak() {
		System.out.println("야옹야옹~~~");
	}
}

class Dog extends Pet {

	@Override
	public void speak() {
		System.out.println("멍멍멍~~ 멍멍멍~~~");
	}

	@Override
	public void song() {
		System.out.println("머어어어어어엉~~~~");
	}
	
}








