package com.interface_test;

public class InterfaceTest {

	public static void main(String[] args) {
		//Pet pet = new Pet();	// 오류 : 추상클래스는 직접 객체생성 불가
		Cat cat = new Cat();
		//cat.name = "냐옹이";	// 인터페이스의 멤버변수는 상수이므로 변경 불가
		cat.speak();
		cat.song();
		System.out.println(cat.name);
		System.out.println();
		
		Dog dog = new Dog();
		//dog.name = "멍멍이";   // 인터페이스의 멤버변수는 상수이므로 변경 불가
		dog.speak();
		dog.song();
		System.out.println(dog.name);
	}
}

// 모든 애완동물에 대한 일반화시킨 부모클래스 : 인터페이스
interface Pet {
	public String name = "메리"; // 자동 상수 : public static final String name = "메리";
	
	public abstract void speak();
	
	public void song();		// 추상메서드 => public abstract void song(); 
//	{
//		System.out.println("라라라라라~~~");
//	}
}

// Pet 인터페이스(부모)클래스를 상속(구현)받은 자식클래스 : 
class Cat implements Pet {
	public void speak() {
		System.out.println("야옹야옹~~~");
	}
	public void song() {
		System.out.println("야야야야야양옹옹~~~");
	}
}

class Dog implements Pet {

	@Override
	public void speak() {
		System.out.println("멍멍멍~~ 멍멍멍~~~");
	}

	@Override
	public void song() {
		System.out.println("머어어어어어엉~~~~");
	}
	
}








