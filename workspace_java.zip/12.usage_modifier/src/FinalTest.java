
public class FinalTest { //extends String {  //public final class String

	public static void main(String[] args) {
		//Math.PI = 1004;  // public static final double PI
	}

}
