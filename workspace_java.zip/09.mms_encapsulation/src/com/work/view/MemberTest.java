package com.work.view;

import com.work.model.biz.MemberManagement;
import com.work.model.dto.Member;

public class MemberTest {
	
	// MemberMangement 회원관리 기능 객체를 이용해서 회원 등록, 조회, 변경, 삭제 테스느
	public static void main(String[] args) {
		// MemberManagement 객체 선언 및 생성 
		MemberManagement mngr = new MemberManagement();
		
		//public Member[] array = new Member[50];
		//mngr.array = null;
		
		// public int index = 0;
		mngr.index = 500;
		
		// 회원등록 : 회원정보 5개 전달해서 회원 등록 메서드 호출수행
		mngr.addMember("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com");
		mngr.addMember("user03", "password03", "이순신", "010-1234-3000", "user03@work.com");
		
		// 회원등록 : 회원객체 생성 전달해서 회원 등록 메서드 호출 수행
		Member dto = new Member("user02", "password02", "강감찬", "010-1234-2000", "user02@work.com", "2020.07.16", "G", 500,"없음");
		mngr.addMember(dto);
		
		dto = new Member("user04", "password04", "강감찬", "010-1234-2400", "user02@work.com", "2020.07.16", "S", 0,"강동원");
		mngr.addMember(dto);
	
		dto = new Member("user05", "password05", "강감찬", "010-1234-2500", "user02@work.com", "2020.07.16", "A", 0,"없음");
		mngr.addMember(dto);

		
		// 회원등록 인원수 조회
		int count = mngr.getSize();
		System.out.println("등록인원수 : " + count);
	
		// 회원등록 전체 조회
		mngr.printMember();
	}
	
	public static void main1(String[] args) {
		// Member 기본속성 5개 초기화 생성자 사용 객체 생성
		Member dto1 = new Member("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com");
		
		// [오류] Member 클래스에서 private 권한 선언 : 외부에서 변경 불가
		//dto1.name = "바보똥개멍텅구리식추아....";
		
		// [해결] 이름을 변경하는 메서드를 이용해서 올바르게 변경 
		
		// [해결] 아이디 변경 해보세요
		dto1.setMemberId("hi"); // 오류 : 6자리 미만
		dto1.setMemberId("hi12345678901234567890"); // 오류 : 12자리 초과
		dto1.setMemberId("happyday");	// 성공
		System.out.println(dto1.getMemberId());	// 변경된 아이디 조회 출력
	}
}









