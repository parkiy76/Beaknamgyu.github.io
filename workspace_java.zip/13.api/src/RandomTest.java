import java.util.Random;

public class RandomTest {
	public static void main(String[] args) {
		//  임의 난수 발급 객체 생성
//		Random random = new Random((long)(Math.random() * 10));
		Random random = new Random((long)(Math.random() * System.nanoTime()));
		
		// 수행속도 성능 테스트 : System.nanoTime()
		
		// 실습 구현해보세요 
		// 보안문자 만들기 : 숫자4자리
		// 힌트 : 
		//	1. 배열 사용 : 4개짜리 배열 생성
		//  2. StringBuilder 객체 생성 사용 => append()
		
		// 1. 배열 사용 : 4개짜리 배열 생성
		// int[] 배열
		int[] array = new int[4];
		for (int index = 0; index < array.length; index++) {
			array[index] = random.nextInt(10);
		}
		String secureData1 = "";
		for (int index = 0; index < array.length; index++) {
			secureData1 += array[index];
		}
		System.out.println(secureData1);
		
		// String[] 배열
		String[] array2 = new String[4];
		for (int index = 0; index < array2.length; index++) {
			//array2[index] = random.nextInt(10);		// 오류 : int => String
			//array2[index] = (String)random.nextInt(10);	// 오류
			
			// 해결 : int 숫자를 문자열 String 변환 : 
			// 1. 숫자 + "" => 숫자를 문자열타입으로 변환
			// 2. String.valueOf(int) : 
			// 3. Wrapper Class : Integer
			
			array2[index] = random.nextInt(10) + "";	// 1.
			array2[index] = String.valueOf(random.nextInt(10)); // 2.
			array2[index] = Integer.toHexString(random.nextInt(10)); // 3.
		}
		
		String secureData2 = "";
		for (int index = 0; index < array2.length; index++) {
			secureData2 += array2[index];
		}
		System.out.println(secureData2);
		
		
		//  2. StringBuilder 객체 생성 사용 => append()
		StringBuilder secureData3 = new StringBuilder();
		for (int index = 0; index < 4; index++) {
			secureData3.append(random.nextInt(10));
		}
		System.out.println(secureData3);
		
	}
	
	
	public static void main1(String[] args) {
		/*## 임의의 숫자 구하기 (난수 구하기)	
			-- java.lang.Math.random();
				=> static double	random()
				
			-- java.util.Random
				=> nextInt()
				=> nextInt(int)
				=> nextBoolean()
		*/
		
		// 실습 : java.lang.Math.random(); 사용해서 임의의 숫자 가져오기
		double no = Math.random();
		System.out.println(no);
		int no3 = (int)no;
		System.out.println(no3);
		System.out.println();
		
		// 임의의숫자 : 정수형 가져오기 1의자리단위 * 10 / 10의자리단위 * 100 => int 형변환
		int no2 = (int)(Math.random() * 10);
		System.out.println(no2);
		
		System.out.println("\n## java.util.Random");
		// Random 객체 생성 : 임의의 long 타입을 seed(아규먼트)로 전달받은 생성자 사용
		Random random = new Random((long)Math.random() * 10);
		
		// 5번반복
		int no4 = 0;
		for (int index = 0; index < 5; index++) {
			//no4 = random.nextInt();
			no4 = random.nextInt(10) + 1;		// 0 ~ 9 사이의 임의숫자 + 1 => 1 ~ 10
			System.out.println(no4);
		}
		
		// 실습 구현해보세요 
		// 보안문자 만들기 : 숫자4자리
		// 힌트 : 
		//	1. 배열 사용 : 4개짜리 배열 생성
		//  2. StringBuilder 객체 생성 사용 => append()
		
	}

}
