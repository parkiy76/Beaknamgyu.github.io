
public class StringTest {

	public static void main(String[] args) {
		String msg1 = "hello";
		String msg2 = "hello";
		String msg3 = new String("hello");
		String msg4 = new String("hello");
		
		// 같은값비교 연산자 == 비교결과 출력
		System.out.println(msg1 == msg2);	// true
		System.out.println(msg1 == msg3);	// false
		
		// 같은객체비교(문자열객체) 메서드 equals() 비교결과 출력
		System.out.println(msg1.equals(msg2));	// true
		System.out.println(msg1.equals(msg3));	// true
		
		// 문자열비교시에는 반드시 같은객체 비교하는 equals() 메서드 사용
		
		msg1 = "welcome";
		for (int index=1; index <= 10000; index++) {
			msg1 += index; // 기본문자열 변경할때마다 메모리 생성 : 메모리 낭비, 비효율적
		}
		
	}

}
