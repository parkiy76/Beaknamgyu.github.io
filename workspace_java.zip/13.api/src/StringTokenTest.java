import java.util.StringTokenizer;

public class StringTokenTest {

	public static void main(String[] args) {
		String data = "user01, password01, 홍길동, 010-1234-1000, user01@work.com";
		
		// String#split()
		String[] data1 = data.split(", ");
		System.out.println("토큰링 갯수" + data1.length);
		
		// jdk1.4  : 토큰 정보 전체 출력
		for (int index = 0; index < data1.length; index++) {
			System.out.println(data1[index]);
		}
		
		System.out.println();
		// jdk1.5  : 토큰 정보 전체 출력
		for(String d : data1) {
			System.out.println(d);
		}
		
		System.out.println();
		// StringTokenizer 사용
		StringTokenizer token = new StringTokenizer(data, ", ");
		int count = token.countTokens();
		System.out.println(" : " + count);
		while(token.hasMoreElements()) {
			String d = token.nextToken();
			
			System.out.println(d);
			System.out.println("남은 토큰갯수 count : " + token.countTokens());
			System.out.println();
		}
	}

}
