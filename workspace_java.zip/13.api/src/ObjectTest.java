
public class ObjectTest {

	public static void main(String[] args) {
		Object obj1 = new Object();
		Object obj2 = new Object();
		
		Object obj3 = obj1;
		
		System.out.println("obj1 : " + obj1.hashCode());
		System.out.println("obj2 : " + obj2.hashCode());
		System.out.println("obj3 : " + obj3.hashCode());
		
		if (obj1.equals(obj2)) {
			System.out.println("obj1과 obj2는 같은 객체입니다.");
			System.out.println(obj1.hashCode());
			System.out.println(obj2.hashCode());
		} else {
			System.out.println("obj1과 obj2는 다른 객체입니다.");
			System.out.println(obj1.hashCode());
			System.out.println(obj2.hashCode());
		}
		
		if (obj1.equals(obj3)) {
			System.out.println("obj1과 obj3는 같은 객체입니다.");
			System.out.println(obj1.hashCode());
			System.out.println(obj3.hashCode());
		} else {
			System.out.println("obj1과 obj3는 다른 객체입니다.");
			System.out.println(obj1.hashCode());
			System.out.println(obj3.hashCode());
		}
		
	}

}
