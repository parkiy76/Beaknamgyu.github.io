package com.work.view;

public class Method {
	// 메서드 유형1 : 반환타입 없고, 아규먼트 없음 
	public void doA() {
		System.out.println("안녕");
	}
	
	// 메서드 유형2 : 반환타입 없고, 아규먼트 있음
	// 아규먼트 1개 : 인사말(String)
	// 수행문 : 아규먼트로 전달받은 인사말을 출력
	// 메서드명 : doB();
	public void doB(String message) {
		System.out.println(message);
	}	
	
	// 메서드 유형3 : 반환타입 있고, 아규먼트 없음
	public int doC() {
		return 1234;
	}
	
	// 메서드 유형4 : 반환타입 있고, 아규먼트 있음
	public int doD(int count) {
		return 1234 * count;
	}
	
	public int doE(int no1, int no2) {
		return no1 + no2;
	}
	
}









