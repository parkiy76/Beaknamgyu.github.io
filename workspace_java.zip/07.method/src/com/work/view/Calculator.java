package com.work.view;

public class Calculator {
	// 실습 추가구현 : 
	public int execute(int no1, char operator, int no2) {
		return 0;
	}
	
	// 실습 1: 2개의 int 정수를 아규먼트로 받아서 덧셈결과 반환메서드
	public int add(int no1, int no2) {
		return no1 + no2;
	}
	
	// 실습 2: 2개의 int 정수를 아규먼트로 받아서 뺄셈결과 반환메서드
	public int subtract(int no1, int no2) {
		return no1 - no2;
	}
	
	// 실습 3: 2개의 int 정수를 아규먼트로 받아서 곲셈결과 반환메서드
	public int multiple(int no1, int no2) {
		return no1 * no2;
	}
	
	// 실습 4: 2개의 int 정수를 아규먼트로 받아서 나눗셈결과 반환메서드
	public int divide(int no1, int no2) {
		return no1 / no2;
	}
}
