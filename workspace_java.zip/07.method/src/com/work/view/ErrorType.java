package com.work.view;

public class ErrorType {
	//System.out.println("aaa");
	// 수행문은 메서드, 생성자 내부에 위치
	public void doA() {
		System.out.println("aaa");
	}
	
	// 메서드안에 메서드 선언
	public void doB() {
		/* 메서드 내부에 다른 메서드 선언 불가
		public void doC() {
			
		}
		*/
	}
	
	public void doC() {
		
	}
	
	public void doD() {
		Calculator calc = new Calculator();
		//int result;
		int result = calc.add(5, 3);
		System.out.println(result);
	}
	
	public void doE() {
		int result;
	}
	
	public void doF() {
		System.out.println();
		System.out.println();
		
		if(true) {
			System.out.println();
			
			if(true) {
				System.out.println();
				System.out.println();
			}
		}
	}			
				
				
}















