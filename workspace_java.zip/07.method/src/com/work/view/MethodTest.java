package com.work.view;

public class MethodTest {

	public static void main(String[] args) {
		// Method 객체를 선언 및  생성
		// 클래스명 참조변수명 = new 클래스명();
		Method m = new Method();
		
		System.out.println("\n## 메서드 유형1 : 반환타입 없고, 아규먼트 없음 ");
		// 생성한  Method 객체의 doA() 메서드 호출
		// 참조변수명.메서드명()
		m.doA();
		
		// doA() 메서드를 5번 호출해보세요
		for (int index = 0; index < 5; index++) {
			m.doA();
		}
		
		System.out.println("\n## 메서드 유형2 : 반환타입 없고, 아규먼트 있음 ");
		
		// 5개의 인사말을 배열에 선언 + 생성 + 초기화 동시 수행 이용해서
		String[] messages = {"펭하", "하이", "안녕하십니까", "반가워요", "밥먹자"};
		
		// 배열에 저장된 인사말을 doB() 메서드의 아규먼트로 전달해서
		// doB() 메서드를 호출해보세요
		m.doB("잘보고있나요");
		
		// jdk1.5
		for (String message : messages) {
			m.doB(message);
		}
		
		System.out.println("\n## 메서드 유형3 : 반환타입 있고, 아규먼트 없음 ");
		int result = m.doC();
		System.out.println("result = " + result);
		
		
		System.out.println("\n## 메서드 유형4 : 반환타입 있고, 아규먼트 있음 ");
		result = m.doD(3);
		System.out.println("result = " + result);
		
		result = m.doD(5);
		System.out.println("result = " + result);
		
		// 계산기(Calculator) 객체를 생성해서 사칙연산 메서드를 호출 수행해보세요
		System.out.println("\n## 계산기 사칙연산");
		Calculator calc = new Calculator();
		
		// 덧셈, 뺄셈, 곲셈, 나눗셈
		result = calc.add(100, 15);
		System.out.println("100 + 15 = " + result);
		
		result = calc.subtract(100, 15);
		System.out.println("100 - 15 = " + result);

		result = calc.multiple(100, 15);
		System.out.println("100 x 15 = " + result);

		result = calc.divide(100, 15);
		System.out.println("100 / 15 = " + result);

	}

}











