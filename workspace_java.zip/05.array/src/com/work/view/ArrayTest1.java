package com.work.view;

public class ArrayTest1 {

	public static void main(String[] args) {
		// 1차원 배열을 이용해서 5명의 학생의 성적을 저장 관리
		
		// 1. 선언 : 타입[] 배열명;
		int[] scores;
		
		// 2. 생성 : 배열명 = new 타입[배열크기];
		scores = new int[5];
		
		// 3. 할당 및 사용 : 배열명[인덱스번호] = 값;
		// jdk1.4 for
		for (int index = 0; index < scores.length; index++) {
			System.out.println(scores[index]);
		}
		
		// 학생의 성적을 저장해보세요
		// 1번학생 : 80
		// 2번학생 : 76
		// 3번학생 : 93
		// 4번학생 : 91
		// 5번학생 : 88
		scores[0] = 80;
		scores[1] = 76;
		scores[2] = 93;
		scores[3] = 91;
		scores[4] = 88;
		
		System.out.println("\n## 학생성적");
		//int sum = 0;
		double sum = 0;
		double avg = 0;
		
		// 학생 전체의 총점을 출력해보세요
		for (int index = 0; index < scores.length; index++) {
			System.out.println((index + 1) + "\t"+ scores[index]);
			sum += scores[index];
		}
		System.out.println("총점 : " + (int)sum);
		
		// 학생 전체의 평균을 출력해보세요
		avg =  sum / scores.length;
		System.out.println("평균 : " + avg);
		
		
		// 학생 5명의 이름을 저장위한 1차원 배열 선언 및 생성
		// 1. 선언 + 2. 생성 : 타입[] 배열명 = new 타입[배열크기];
		String[] names = new String[5];
		
		// 3. 배열요소 값할당 : 학생이름 저장
		names[0] = "홍길동";
		names[1] = "강감찬";
		names[2] = "이순신";
		names[3] = "김유신";
		names[4] = "유관순";
		
		// 성적배열, 이름배열을 이용해서 학생의 성적 정보를 출력
		// 출력형식 : 예시 참고하세요
		// 번호 	이름		성적
		// 1	홍길동	80
		// 2	...		...
		// 총점
		// 평균
		System.out.println();
		sum = 0;
		avg = 0;
		
		for (int index = 0; index < scores.length; index++) {
			System.out.println((index + 1) + "\t" + names[index] + "\t"+ scores[index]);
			sum += scores[index];
		}
		System.out.println("총점 : " + (int)sum);
		
		// 학생 전체의 평균을 출력해보세요
		avg =  sum / scores.length;
		System.out.println("평균 : " + avg);
		
		//-- 1. 선언 + 2. 생성 + 3. 할당 동시 수행
		//-- 주의사항 : 맨뒤에 ;(세미콜론) 반드시 표기해야함
		//	타입[] 배열명 = {초기값1, 초기값N};
		//	타입[] 배열명 = new 타입[]{초기값1, 초기값N};

		int[] nos = {32, 48, 57, 65, 100, 88, 78};
		String[] messages = new String[] {"안녕", "잘지내니", "오래만이야", "아프지않지"};
		
		// jdk 1.4
		for (int index = 0; index < nos.length; index++) {
			System.out.println(nos[index]);
		}
		System.out.println();
		
		for (int index = 0; index < messages.length; index++) {
			System.out.println(messages[index]);
		}
		System.out.println();

		// jdk 1.5
		for (int no : nos) {
			System.out.println(no);
		}
		System.out.println();
		
		for (String message : messages) {
			System.out.println(message);
		}

	}
}
























