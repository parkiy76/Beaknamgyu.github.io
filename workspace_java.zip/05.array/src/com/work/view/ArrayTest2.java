package com.work.view;

public class ArrayTest2 {

	public static void main(String[] args) {
		// 2차원 배열 : 행과 열크기 동일
		int[][] nos = new int[2][3];
		
		// 0번행 값 할당
		nos[0][0] = 10;
		nos[0][1] = 20;
		nos[0][2] = 30;
		
		// 1번행 값 할당
		nos[1][0] = 50;
		nos[1][1] = 80;
		nos[1][2] = 70;
		
		// 2차원행렬 출력
		for (int row = 0; row < nos.length; row++) {	// 행반복
			for (int col = 0; col < nos[row].length; col++) { // 해당행의 열반복
				System.out.print(nos[row][col] + "\t");
			}
			System.out.println();
		}
		
		System.out.println();
		// 2차원 배열 : 행과 마다 열의크기 다르게 지정
		int[][] nos2;
		
		// 3행 짜리 2차원 배열생성
		// 0행 5개열 : 10, 20, 30, 40, 50
		// 1행 3개열 : 50, 80, 70
		// 2행 2개열 : 90, 70
		
		// 2차원배열명 = new 타입[행크기][];
		nos2 = new int[3][]; // 3행 짜리 2차원 배열생성 

		// 2차원배열명[행번호] = new 타입[열크기];
		nos2[0] = new int[5]; 	// 0행 5개열 : 10, 20, 30, 40, 50
		nos2[1] = new int[3];
		nos2[2] = new int[2];
		
		// 0행 : 10, 20, 30, 40, 50
		nos2[0][0] = 10;
		nos2[0][1] = 20;
		nos2[0][2] = 30;
		nos2[0][3] = 40;
		nos2[0][4] = 50;
		
		// 1행: 50, 80, 70
		nos2[1][0] = 50;
		nos2[1][1] = 80;
		nos2[1][2] = 70;
	
		// 2행  : 90, 70
		nos2[2][0] = 90;
		nos2[2][1] = 70;
	
		for (int row = 0; row < nos2.length; row++) {	// 행반복
			for (int col = 0; col < nos2[row].length; col++) { // 해당행의 열반복
				System.out.print(nos2[row][col] + "\t");
			}
			System.out.println();
		}
		
		System.out.println();
		// ## 2차원 1. 선언 + 2. 생성 + 3. 할당 동시 수행
		int[][] nos3 = {
				{10, 20, 30, 40, 50},
				{50, 80, 70},
				{90, 70}
		};
		
		for (int row = 0; row < nos3.length; row++) {	// 행반복
			for (int col = 0; col < nos3[row].length; col++) { // 해당행의 열반복
				System.out.print(nos3[row][col] + "\t");
			}
			System.out.println();
		}
		
	}

}


