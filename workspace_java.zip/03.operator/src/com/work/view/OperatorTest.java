package com.work.view;

public class OperatorTest {

	public static void main(String[] args) {
		int no1 = 8 + 5;
		int no2 = 8 % 5;
		System.out.println("no1 = " + no1);
		System.out.println("no2 = " + no2);
	}

}
