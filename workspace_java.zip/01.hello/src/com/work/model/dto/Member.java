package com.work.model.dto;

public class Member {

}
