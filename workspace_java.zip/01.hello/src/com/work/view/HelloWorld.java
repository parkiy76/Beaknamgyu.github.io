package com.work.view;

import java.util.Date;

public class HelloWorld {

	/**  자바 시작 메서드 */
	public static void main(String[] args) {
		// 메서드 내부에 선언한 지역변수 및 초기화
		String name = "임경혜";
		
		// 콘솔창 출력 수행문
		System.out.println("안녕하세요 선문대 여러분 학교 교정이 너무 멋지네요..반갑습니다.");
		System.out.println(name);
		
		Date today = new Date();
	}
}
