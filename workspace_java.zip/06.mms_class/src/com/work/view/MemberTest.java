package com.work.view;

import com.work.model.dto.Member;

public class MemberTest {

	public static void main(String[] args) {
		/*
		 	## new 객체 생성 절차(순서)
			1. 메모리 할당
			2. 기본값 자동 초기화
			3. 명시적 초기화
			4. 생성자 수행
			5. 참조값 할당
		*/
		// 회원객체 선언 및 생성 : 기본생성자 사용
		Member dto = new Member();
		
		// 생성한 회원객체의 속성정보를 본인정보로 변경
		dto.memberId = "khim98";
		dto.memberPw = "bluesky";
		dto.name = "임경혜";
		dto.phone = "010-2831-2773";
		dto.email = "khim98@empal.com";
		
		// 생성한 회원객체의 현재 정보를 조회출력
		System.out.println("\n### 회원정보");
		System.out.println(dto.memberId);
		System.out.println(dto.memberPw);
		System.out.println(dto.name);
		System.out.println(dto.phone);
		System.out.println(dto.email);
		
		System.out.println(dto.entryDate);	// 객체생성시에 기본값 자동초기화 정보로 출력됨
		System.out.println(dto.grade);
		System.out.println(dto.point);
		System.out.println(dto.manager);
		
		// 새로운 회원객체를 새로이 생성해서
		Member dto2 = new Member();
		
		// 새로이 생성한 회원객체의 속성정보를 변경 설정하고
		// 모든정보를 변경 설정하세요 : 가입일, 등급, 마일리지, 담당자
		dto2.memberId = "ekkim";
		dto2.memberPw = "happyday";
		dto2.name = "김은경";
		dto2.phone = "010-1234-1000";
		dto2.email = "ekkim@work.com";	
		
		dto2.entryDate = "2020.07.15";
		dto2.grade = "G";
		dto2.point = 500;
		dto2.manager = "없음";
		
		// 새로이 생성한 회원객체의 현재 정보를 조회출력
		System.out.println("\n### 회원정보");
		System.out.println(dto2.memberId);
		System.out.println(dto2.memberPw);
		System.out.println(dto2.name);
		System.out.println(dto2.phone);
		System.out.println(dto2.email);
		
		System.out.println(dto2.entryDate);
		System.out.println(dto2.grade);
		System.out.println(dto2.point);
		System.out.println(dto2.manager);
	
		// Member 타입의 변수 선언
		Member dto3 = dto;  // 같은 객체를 참조 
		dto = null;		// null 해당 객체를 더이상 참조하지 않음
		dto3 = null;	// 어떠한 객체도 참조하지 않으므로 메모리에서 자동해제 : Garbage Collector 발생함
		
		dto.memberId = "user01";	// 실행시 예외발생 : java.lang.NullPointerException
		dto3.memberId = "test01";
	}

}









