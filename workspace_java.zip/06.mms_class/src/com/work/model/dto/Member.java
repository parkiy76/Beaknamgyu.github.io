package com.work.model.dto;

public class Member {
	public String memberId = "guest";
	public String memberPw;
	public String name;
	public String phone;
	public String email;
	public String entryDate;
	public String grade;
	public int point;
	public String manager;
	
}
