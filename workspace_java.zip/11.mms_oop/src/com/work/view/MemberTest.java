package com.work.view;

import java.util.Date;

import com.work.model.dto.AdminMember;
import com.work.model.dto.GeneralMember;
import com.work.model.dto.Member;
import com.work.model.dto.SpecialMember;

public class MemberTest {
	public static void main(String[] args) {
		// 다형성 : 변수타입(가장 최상위 객체타입 => 모든 객체 저장가능한 변수)
		Object obj = new Object();
		
		Object obj1 = "hello";
		Object obj2 = new Date();
		Object obj3 = new Member("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com");
		
		System.out.println(obj.toString());
		
		System.out.println(obj1.toString());
		System.out.println(obj2.toString());
		System.out.println(obj3.toString());
		System.out.println();
		
		// Member 타입 다형성 테스트
		GeneralMember g1 = new GeneralMember();
		// g1 = new SpecialMember(); // 오류 : 다른타입
		
		Member m = new GeneralMember();		// Member 자식들을 모두 참조할 수 있는 회원부모타입 가능
		// 일반 : 포인트
		//m.setPoint(100);		// 오류 : 부모타입의 변수로 선언되어있므로 자식의 멤버 접근 불가
		GeneralMember g = (GeneralMember)m;	// 실제 메모리에 생성한 자식객체타입으로 명시적 형변환 => 자식 멤버 접근 가능
		g.setPoint(1000);
		
		System.out.println(m.toString());	// 상속받은 재정의 메서드는 부모타입이어도 자식이 재정의해놓은 메서드 자동 호출 수행
		System.out.println(g.toString());
		System.out.println();
		
		m = new SpecialMember();
		// 우수 : 담당자
		//m.setManager("강동원"); 	// 오류 : 부모타입의 변수로 선언되어있므로 자식의 멤버 접근 불가
		SpecialMember s = (SpecialMember)m;
		s.setManager("강동원");
		System.out.println(m.toString());	// 상속받은 재정의 메서드는 부모타입이어도 자식이 재정의해놓은 메서드 자동 호출 수행
		System.out.println();
		
		m = new AdminMember();
		// 관리자 : 직책
		//m.setPosition("과장"); 	// 오류 : 부모타입의 변수로 선언되어있므로 자식의 멤버 접근 불가
		AdminMember a = (AdminMember)m;
		a.setPosition("과장");
		System.out.println(m.toString());	// 상속받은 재정의 메서드는 부모타입이어도 자식이 재정의해놓은 메서드 자동 호출 수행
		System.out.println();
	}
}




















