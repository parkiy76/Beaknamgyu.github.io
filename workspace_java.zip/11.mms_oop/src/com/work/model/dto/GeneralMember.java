package com.work.model.dto;

// Member 클래스를 상속받은 일반회원 자식클래스
// 일반회원 기본 생성자:
// 일반회원 필수 초기화 생성자: 공통(아이디,비밀번호,이름,휴대폰,이메일)
// 일반회원 전체 초기화 생성자: 공통전체(아이디,비밀번호,이름,휴대폰,이메일,가입일,등급) + 포인트
public class GeneralMember extends Member {
	// 일반회원 포인트 멤버변수 추가
	private int point;
	
	// 일반회원 기본 생성자:
	public GeneralMember() {
		// 자식의 생성자에서 부모생성자를 명시적으로 지정하지 않으면 부모의 기본생성자 호출 자동 추가됨 : super()
		// 부모의 생성자에 기본생성자가 반드시 선언되어 있어야함
		//super("","","","","");
	}
	
	// 일반회원 필수 초기화 생성자: 공통(아이디,비밀번호,이름,휴대폰,이메일)
	public GeneralMember(String memberId, String memberPw, String name, String phone, String email) {
		super(null, null, null, null, null);
		
		//this.memberId = memberId; // 오류 : 부모가 private 선언해서 자식 직접 사용불가
		setMemberId(memberId);
		setMemberPw(memberPw);
		setName(name);
		setPhone(phone);
		setEmail(email);
	}
	
	// 일반회원 전체 초기화 생성자: 공통전체 + 포인트
	public GeneralMember(String memberId, String memberPw, String name, String phone, String email,
			String entryDate, String grade, int point) {
		this(memberId, memberPw, name, phone, email);
		setEntryDate(entryDate);
		setGrade(grade);
		this.point = point;
	}
	
	// setters() / getters()
	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}
	
	@Override
	public String toString() {
		return getMemberId() + ", " + getMemberPw() + ", " + getName() + ", " + getPhone() + 
				", " + getEmail() + ", " + getEntryDate() + ", " + getGrade() + ", " + point;
	}
	
}
















