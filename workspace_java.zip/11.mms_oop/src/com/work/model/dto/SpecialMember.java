package com.work.model.dto;

public class SpecialMember extends Member {
	// 우수회원 담당자  멤버변수 추가
	private String manager;

	public SpecialMember() {
	}

	public SpecialMember(String memberId, String memberPw, String name, String phone, String email, String entryDate,
			String grade, String manager) {
		super(memberId, memberPw, name, phone, email, entryDate, grade);
		this.manager = manager;
	}

	public SpecialMember(String memberId, String memberPw, String name, String phone, String email) {
		super(memberId, memberPw, name, phone, email);
	}

	// setters() / getters()
	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	@Override
	public String toString() {
		return super.toString() + ", " + manager;
	}
	 
	
}














