package com.work.model.dto;

public class AdminMember extends Member {
	// 관리자 직책(position : 사원 대리 과장) 멤버변수 추가
	private String position;

	public AdminMember() {
		super();
	}

	public AdminMember(String memberId, String memberPw, String name, String phone, String email, String entryDate,
			String grade, String position) {
		super(memberId, memberPw, name, phone, email, entryDate, grade);
		this.position = position;
	}

	public AdminMember(String memberId, String memberPw, String name, String phone, String email) {
		super(memberId, memberPw, name, phone, email);
	}

	// setters() / getters()
	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	@Override
	public String toString() {
		return super.toString() + ", " + position;
	}
}















