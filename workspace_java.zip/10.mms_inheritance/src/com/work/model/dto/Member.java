package com.work.model.dto;

/** 모든 회원클래스의 부모 클래스 (공통) */
public class Member {
	private String memberId = "guest";
	private String memberPw;
	private String name;
	private String phone;
	private String email;
	private String entryDate;
	private String grade;
	
	// 기본생성자 : 생성자 중복정의시에 기본생성자도 명시적으로 함께 중복정의 권장 : 상속시에 자식객체에서 부모 명시적 지정 생략 가능
	public Member() {
		super();
		System.out.println("부모 기본생성자");
	}

	// 필수 초기화 생성자 : 아이디, 비밀번호, 이름, 휴대폰, 이메일
	public Member(String memberId, String memberPw, String name, String phone, String email) {
		super();
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.phone = phone;
		this.email = email;
		System.out.println("부모 필수 초기화생성자");
	}

	// 전체데이터 초기화 생성자 : 아이디, 비밀번호, 이름, 휴대폰, 이메일 + 가입일, 등급
	public Member(String memberId, String memberPw, String name, String phone, String email, String entryDate,
			String grade) {
		super();
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.entryDate = entryDate;
		this.grade = grade;
		System.out.println("부모 전체 초기화생성자");
	}

	// setters() / getters()
	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberPw() {
		return memberPw;
	}

	public void setMemberPw(String memberPw) {
		this.memberPw = memberPw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return memberId + ", " + memberPw + ", " + name + ", " + phone + ", " + email + ", " + entryDate + ", " + grade;
	}
	
}















