package com.work.model.biz;

import com.work.model.dto.Member;

/*  회원 관리 기능 클래스 
	기능 : 등록, 조회, 변경, 삭제 
*/
public class MemberManagement {
	// 회원들의 정보를 저장위한 자료저장구조 : 배열
	private Member[] array = new Member[50];
	
	// 회원을 등록위한 배열의 위치 인덱스 번호 및 현재 등록한 회원 숫자 정보
	public int index = 0;
	
	// 현재 등록한 회원수 반환 메서드
	public int getSize() {
		return index;
	}
	
	// 회원등록(아이디, 비밀번호, 이름, 휴대폰, 이메일)
	public void addMember(String memberId, String memberPw, String name, String phone, String email) {
		// 아규먼트로 전달받은 정보를 갖는 Member 객체 생성
		Member dto = new Member(memberId, memberPw, name, phone, email);
		
		// 아규먼트로 전달받아 생성한 회원객체를 배열요소에 할당(저장)
		array[index++] = dto;
	}
	
	// 회원등록(회원객체Member) 중복정의
	public void addMember(Member dto) {
		array[index++] = dto;
	}
	
	// 현재 등록한 전체인원을 출력하는 메서드 
	public void printMember() {
		// 현재 등록한 인원수 만큼 반복하면서 인덱스 하나씩 증가하면서 해당객체의 toString() 메서드 호출 수행 출력
		for (int index = 0; index < getSize(); index++) {
			System.out.println(array[index].toString());
		}
	}
	
	public void doA(String data1, final String data2) {
		data1 = "aaaa";
//		data2 = "bbbb";
	}
	
}











