package com.work.view;

import com.work.model.dto.AdminMember;
import com.work.model.dto.GeneralMember;
import com.work.model.dto.SpecialMember;

public class MemberTest {
	public static void main(String[] args) {
		// 일반회원 기본생성자 객체생성
		GeneralMember g1 = new GeneralMember();
		System.out.println();
		
		// 우수회원 기본생성자 객체생성
		SpecialMember s1 = new SpecialMember();
		System.out.println();
		
		// 관리자 기본생성자 객체생성
		AdminMember a1 = new AdminMember();
		System.out.println();
		
		// 오류발생 : 부모클래스가 private 멤버로 선언해서 자식이라도 접근사용불가
		//g1.memberId = "일반아이디";
		
		g1.setMemberId("일반아이디");
		s1.setMemberId("우수아이디");
		a1.setMemberId("관리자아이디");
		
		System.out.println(g1.getMemberId());
		System.out.println(s1.getMemberId());
		System.out.println(a1.getMemberId());
	}
}









