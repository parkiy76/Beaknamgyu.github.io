package com.work.util;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 <pre>
 	## Utility 클래스
 	-- 공통으로 사용하는 메서드들로 구성한 클래스 
 	
	## API 활용해서 아래의 요구사항을 구현해보세요
	-- package : com.work.util
	-- class name : Utility.java
	-- Utility에 있는 모든 메서드는 객체 생성하지 않고 사용할 수 있도록 static 메서드 선언
		=> 예시: public static 반환타입 메서드이름(아규먼트){}
	
	1. 현재 날짜를 기본형식의 문자열로 변환하는 반환하는 메서드	
	-- 기본형식 : 년도4자리.월2자리.일2자리 (예: 2020.07.20)
	-- 메서드명 : + getCurrentDate(): String
	-- 참고 api :
		=> java.util.Date
		=> java.text.SimpleDateFormat >> java.text.DateFormat
		=> java.lang.String , java.lang.StringBuiler
		
	2. 정수형(int) 숫자 데이터를 아규먼트로 받아서 천단위마다 컴마표기한 문자열로 변환 반환하는 메서드
	-- 메서드명 : + convertNumberString(int): String
	-- 참고 api :
		=> java.text.NumberFormat
		=> java.lang.String , java.lang.StringBuiler
	
	3. 임의의 보안문자 숫자형식의 4자리 문자열 반환하는 메서드 
	-- 중복정의 : 아규먼트 없으면 기본 숫자 4자리, 아규먼트가 있으면 해당 아규먼트 길이만큼의 숫자
	-- 메서드명 : 
		+ getSecureNumberString(): String
		+ getSecureNumberString(int): String
		
	-- 참고 api :
		=> java.util.Random
		=> java.lang.System
		=> java.lang.StringBuiler
</pre>
*/
public class Utility {
	// 1. 현재 날짜를 기본형식의 문자열로 변환하는 반환하는 메서드
	// -- 기본형식 : 년도4자리.월2자리.일2자리 (예: 2020.07.20)
	// -- 메서드명 : + getCurrentDate(): String
	public static String getCurrentDate() {
		return null;
	}

	public static String getCurrentDate(String pattern) {
		return null;
	}
	
	public static String getCurrentDate(String pattern, Locale locale) {
		return null;
	}
	
	// 2. 정수형(int) 숫자 데이터를 아규먼트로 받아서 천단위마다 컴마표기한 문자열로 변환 반환하는 메서드
	// -- 메서드명 : + convertNumberString(int): String
	public static String convertNumberString(int no) {
		return null;
	}
	
	// 기본 화폐단위 기호 맨앞에표기 + 천단위마다 컴마 표기 문자열 변환
	public static String convertCurrencyNumberString(int no) {
		return null;
	}
	
	// 3. 임의의 보안문자 숫자형식의 4자리 문자열 반환하는 메서드
	// + getSecureNumberString(): String
	// + getSecureNumberString(int): String
	public static String getSecureNumberString() {
		return null;
	}
	
	public static String getSecureNumberString(int length) {
		return null;
	}
	
	// 영문대문자 기본 4자리 문자열 반환 메서드
	public static String getSecureString() {
		return null;
	}

	// 아규먼트로 입력받은 길이만큼의 영문대문자 문자열 반환 메서드
	// 영어 알파벳 총 26자
	// 영문 대문자 아스키코드 : 65
	// 영문 소문자 아스키코드 : 97
	public static String getSecureString(int length) {
		return null;
	}
	
	// 아규먼트로 입력받은 길이만큼의 isUpper가 true이면 영문 대문자 false이면 영문 소문자 문자열 반환 메서드
	public static String getSecureString(int length, boolean isUpper) {
		return null;
	}

	// 아규먼트로 입력받은 길이만큼의 isUpper가 true이면 영문 대문자 false이면 영문 소문자 및 숫자조합 문자열 반환 메서드 
	public static String getSecureNumberAndString(int length, boolean isUpper) {
		return null;
	}	
	/**
	 * 유틸리티 클래스 테스트 시작 메서드
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("\n### 날짜 테스트");
		System.out.println(Utility.getCurrentDate());
		System.out.println(Utility.getCurrentDate("yyyy/MM/dd"));
		System.out.println(Utility.getCurrentDate("hh:mm:ss"));
		System.out.println(Utility.getCurrentDate("yyyy/MM/dd a hh:mm"));
		System.out.println(Utility.getCurrentDate("yyyy/MM/dd a hh:mm", Locale.US));
		System.out.println(Utility.getCurrentDate("yyyy/MM/dd a hh:mm", Locale.CHINA));
		
		int no = 123456789;
		System.out.println("\n### 숫자 천단위 컴마표기 테스트");
		System.out.println(no);
		System.out.println(Utility.convertNumberString(no));
		
		System.out.println("\n### 화페 단위 숫자 천단위 컴마표기 테스트");
		System.out.println(Utility.convertCurrencyNumberString(no));
		
		System.out.println("\n### 보안문자 테스트");
		System.out.println(Utility.getSecureNumberString());
		System.out.println(Utility.getSecureNumberString(6));
		System.out.println(Utility.getSecureNumberString(10));
		System.out.println();
		
		System.out.println(Utility.getSecureString());
		System.out.println(Utility.getSecureString(6));
		System.out.println(Utility.getSecureString(10));
		
		System.out.println();
		System.out.println(Utility.getSecureString(6, false));
		System.out.println(Utility.getSecureString(10, false));
		System.out.println(Utility.getSecureString(10, true));
		
		System.out.println();
		System.out.println(Utility.getSecureNumberAndString(8, false));
		System.out.println(Utility.getSecureNumberAndString(8, false));
		System.out.println(Utility.getSecureNumberAndString(10, false));
		System.out.println(Utility.getSecureNumberAndString(10, true));
	}

}
