package com.work.view;

import java.util.ArrayList;
import java.util.Date;

import com.work.model.dto.Member;

public class ArrayListTest {

	// Member의 인스턴스 여부 검증하지 않고  Member 클래스로 형변환 : 실행시 예외 발생
	public static void main2(String[] args) {
		ArrayList list = new ArrayList();
		
		list.add("hello");
		list.add(1234567);	// 자동형변환 int => Integer 객체 변환 등록(auto boxing)
		list.add(new Date());
		list.add(new Member("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com"));
		list.add(new Member("user02", "password02", "홍길동", "010-1234-1000", "user01@work.com"));
		list.add(new Member("user03", "password03", "홍길동", "010-1234-1000", "user01@work.com"));
	
		System.out.println("저장된 객체 갯수 : " + list.size());
		
		for (int index = 0; index < list.size(); index++) {
			Object obj = list.get(index);
			
			//String memberId = obj.getMemberId();	// 컴파일오류 : 부모타입이므로 자식의 멤버접근불가
			
			// 해당클래스의 인스턴스 여부 비교하지 않고 캐스팅
			Member dto = (Member)obj;	
			// 컴파일은 문법적 오류만 체킹 , 실행시에 Member의 인스턴스가 아닌경우 형변환시 예외발생
			// java.lang.ClassCastException:
			
			String memberId = dto.getMemberId();
			System.out.println("회원 아이디 : " + memberId);
		}
		
		System.out.println("테스트 정상 종료됩니다.");
		
	}
	
	// 형변환전에 Member의 인스턴스 여부검증후 형변환
	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		
		list.add("hello");
		list.add(1234567);	// 자동형변환 int => Integer 객체 변환 등록(auto boxing)
		list.add(new Date());
		list.add(new Member("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com"));
		list.add(new Member("user02", "password02", "홍길동", "010-1234-1000", "user01@work.com"));
		list.add(new Member("user03", "password03", "홍길동", "010-1234-1000", "user01@work.com"));
	
		System.out.println(list.size());
		for (int index = 0; index < list.size(); index++) {
			Object obj = list.get(index);
			
			// 형변환전에 해당클래스의 인스턴스 여부 비교해서 인스턴스이면 형변환
			if (obj instanceof Member) {
				// 해당클래스의 인스턴스 여부 비교하지 않고 캐스팅
				Member dto = (Member)obj;	
				// 컴파일은 문법적 오류만 체킹 , 실행시에 Member의 인스턴스가 아닌경우 형변환시 예외발생
				// java.lang.ClassCastException:
				String memberId = dto.getMemberId();
				System.out.println("회원 아이디 : " + memberId);
			} else {
				System.out.println("[오류] 등록된 객체가 Member 아닙니다. 형변환 할 수 없습니다.");
			}
		}
		
		System.out.println("테스트 정상 종료됩니다.");
	}

}
