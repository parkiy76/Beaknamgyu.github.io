package com.work.view;

import java.util.ArrayList;

import com.work.model.biz.MemberManagement;
import com.work.model.dto.Member;

public class MemberTest {

	public static void main(String[] args) {
		/* 제공된 프로젝트 docs 폴더에 회원_초기데이터.xlsx 파일 회원정보를 참고로하여 5명의 Member 객체를 생성하세요
		
		 아이디	비밀번호		이름		휴대폰			이메일			가입일		등급	포인트	담당자
		user01	password01	홍길동	010-1234-1000	user01@work.com	2020.01.20	G	10000	
		user02	password02	강감찬	010-1234-2000	user02@work.com	2020.02.21	G	50000	
		user03	password03	이순신	010-1234-3000	user03@work.com	2020.03.22	S		       강동원
		user04	password04	김유신	010-1234-4000	user04@work.com	2020.04.23	S		       아이유
		user05	password05	유관순	010-1234-5000	user05@work.com	2020.05.24	A		
		*/
		
		// 초기 등록 회원객체 
		Member dto1 = new Member("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com", "2020.01.20", "G", 10000, "없음");
		Member dto2 = new Member("user02", "password02", "강감찬", "010-1234-2000", "user02@work.com", "2020.02.21", "G", 50000, "없음");
		Member dto3 = new Member("user03", "password03", "이순신", "010-1234-3000", "user03@work.com", "2020.03.22", "S", 0, "강동원");
		Member dto4 = new Member("user04", "password04", "김유신", "010-1234-4000", "user04@work.com", "2020.04.23", "S", 0, "아이유");
		Member dto5 = new Member("user05", "password05", "유관순", "010-1234-5000", "user05@work.com", "2020.05.24", "A", 0, "");
		
		// 회원 crud 기능을 사용하기 위한 객체 생성 
		MemberManagement mngr = new MemberManagement();
		
		// 회원등록 : 회원 5명 초기데이터 등록
		mngr.addMember(dto1);
		mngr.addMember(dto2);
		mngr.addMember(dto3);
		mngr.addMember(dto4);
		mngr.addMember(dto5);
	
		System.out.println("현재 등록 인원수 : " + mngr.getSize());
		
		// 회원등록 : 동일한 아이디로 회원 등록 
		System.out.println();
		boolean result = mngr.addMember(dto5);
		if (!result) {
			System.out.println("[오류] 동일한 아이디가 존재하므로 사용할 수가 없습니다. : " + dto5.getMemberId());
		}
		
		// 회원조회 : user01 
		System.out.println("\n### 회원조회");
		Member dto = mngr.getMember("user01");
		if (dto != null) {
			System.out.println(dto);
		} else {
			System.out.println("[오류] 회원의 정보를 찾을 수 없습니다." + ":user01");
		}
		
		// 회원조회 : 없는 아이디 user99
		System.out.println();
		dto = mngr.getMember("user99");
		if (dto != null) {
			System.out.println(dto);
		} else {
			System.out.println("[오류] 회원의 정보를 찾을 수 없습니다." + " : user99");
		}
				
		// 회원변경 : user01, 변경비밀번호, 변경이름, 변경휴대폰, 변경이메일, (가입일 변경불가, 등급 변경불가, 마일리지 변경불가, 담당자 변경불가)
		System.out.println();
		dto1 = new Member("user01", "bluesky", "임경혜", "010-2831-2773", "khim98@empal.com", "2020.01.20", "G", 10000, "없음");
		result = mngr.setMember(dto1);
		if (result) {
			dto = mngr.getMember("user01");
			System.out.println("변경회원정보 : " + dto);
		} else {
			System.out.println("[오류] 회원의 정보를 찾을 수 없습니다." + " : user01");
		}
		
		// 회원변경 : 없는아이디 user99, 변경비밀번호, 변경이름, 변경휴대폰, 변경이메일, (가입일 변경불가, 등급 변경불가, 마일리지 변경불가, 담당자 변경불가)
		System.out.println();
		dto1 = new Member("user99", "bluesky", "임경혜", "010-2831-2773", "khim98@empal.com", "2020.01.20", "G", 10000, "없음");
		result = mngr.setMember(dto1);
		if (result) {
			dto = mngr.getMember("user99");
			System.out.println("변경회원정보 : " + dto);
		} else {
			System.out.println("[오류] 회원의 정보를 찾을 수 없습니다." + " : user99");
		}
		
		// 회원삭제 : user01
		System.out.println();
		result = mngr.removeMember("user02");
		if (result) {
			System.out.println("회원 삭제 완료 : user02");
		} else {
			System.out.println("[오류] 회원의 정보를 찾을 수 없습니다." + " : user02");
		}
		
		// 회원삭제 : 없는 아이디 user99
		System.out.println();
		result = mngr.removeMember("user99");
		if (result) {
			System.out.println("회원 삭제 완료 : user99");
		} else {
			System.out.println("[오류] 회원의 정보를 찾을 수 없습니다." + " : user99");
		}	
		
		// 회원삭제 : user03/password03
		result = mngr.removeMember("user03", "password03");
		
		// 회원삭제 : user04/password1234 틀린암호
		result = mngr.removeMember("user04", "password1234");
		
		// 전체회원 조회
		System.out.println();
		System.out.println("현재 등록 인원수 : " + mngr.getSize());
		ArrayList list = mngr.getMemberList();
		for (int index = 0; index < list.size(); index++) {
			System.out.println(list.get(index));	// 재정의규칙: 부모타입이어도 재정의한 메서드는 자식이 재정의한 메서드 호출 수행
		}
	}
	
	public static void main2(String[] args) {
		// Member 회원객체 타입 변수 선언 및 회원객체 생성 : 생성자 중복정의 참고
		
		// 1. 기본생성자 사용 객체 생성
		Member dto1 = new Member();
		
		dto1.setMemberId("user01");
		dto1.setMemberPw("password01");
		dto1.setName("홍길동");
		dto1.setPhone("010-1234-1000");
		dto1.setEmail("user01@work.com");
		dto1.setEntryDate("2020.01.20");
		dto1.setGrade("G");
		dto1.setPoint(10000);
		//dto1.setManager("없음");
 
		// 2. 필수데이터 초기화 생성자 사용 객체생성
		Member dto5 = new Member("user05", "password05", "유관순", "010-1234-5000", "user05@work.com");
		dto5.setEntryDate("2020.05.24");
		dto5.setGrade("A");
		
		// 3. 전체데이터 초기화 생성자 사용 객체생성
		Member dto4 = new Member("user04", "password04", "김유신", "010-1234-4000", "user04@work.com", "2020.04.23", "S", 0, "아이유");
	}

}



