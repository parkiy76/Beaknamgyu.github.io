package com.work.model.biz;

import java.util.ArrayList;

import com.work.model.dto.Member;

/**
 * <pre>
 * 회원들을 관리(등록,조회,변경,삭제)위한 기능 구현 클래스
 * </pre>
 * @author 임경혜
 *
 */
public class MemberManagement {
	/** 회원 자료저장 멤버변수 */
	private ArrayList list = new ArrayList();

	/**
	 * 등록한 회원수 반환
	 * @return 등록 회원수, 등록회원이 없으면 0
	 */
	public int getSize() {
		return list.size();
	}
	
	/**
	 * 회원이 등록된 저장구조의 위치인 인덱스번호
	 * 1. 저장된 회원의 크기만큼 반복하면서
	 * 2. 저장된 회원객체를 하나씩 가져와서 : 조회 : get(int) : Object
	 * 3. 가져온 객체가 Member의 인스턴스(객체)인지 비교해서 : instanceof
	 * 4. Member의 인스턴스이면 Member 타입으로 형변환 : (클래스이름)참조변수
	 * 5. 형변환한 회원객체의 아이디와 아규먼트로 전달받은 아이디가 같은지 비교해서 : equals()
	 * 6. 아이디가 같으면 현재의 인덱스번호가 저장된 객체의 저장위치이므로 현재 인덱스 반환
	 * 
	 * 7. 반복을 다했는데도 반환되지 않았다면 동일한 아이디가 존재하지 않으므로 
	 * 	   아이디가 존재하지 않으면 -1 반환
	 * 
	 * @param memberId 회원아이디
	 * @return 존재하면 해당 인덱스번호, 미존재시 -1
	 */
	private int getIndex(String memberId) {
		for (int index = 0; index < list.size(); index++) { // 1
			Object obj = list.get(index);	// 2
			if (obj instanceof Member) {	// 3
				Member dto = (Member)obj;	// 4
				if (dto.getMemberId().equals(memberId)) {	// 5
					return index;			// 6
				}
			}
		}
		
		return -1;	// 7
	}
	
	/**
	 * 회원 등록 메서드
	 * 
	 * 1. 저장된 회원의 크기만큼 반복하면서
	 * 2. 저장된 회원객체를 하나씩 가져와서 : 조회 : get(int) : Object
	 * 3. 가져온 객체가 Member의 인스턴스(객체)인지 비교해서 : instanceof
	 * 4. Member의 인스턴스이면 Member 타입으로 형변환 : (클래스이름)참조변수
	 * 5. 형변환한 회원객체의 아이디와 아규먼트로 전달받은 회원객체의 아이디 getMemberId()가 같은지 비교해서 : equals()
	 * 
	 * 6. 아이디가 같으면 동일한 아이디가 존재하므로 등록 불가 오류, return false 반환
	 * 
	 * 7. 반복을 다했는데도 반환되지 않았다면 동일한 아이디가 존재하지 않으므로 
	 * 	   아규먼트로 전달받은 회원객체를 list(자료저장구조)에 등록 : add(Object) : boolean 하고
	 * 	  return true 반환
	 * 
	 * -- getIndex(String memberId) : int 사용
	 * 1. 아규먼트로 전달받은 아이디의 저장위치 조회
	 * 2. 저장위치가 -1과 같으면 존재하지 않으므로 등록하고 return true
	 * 3. 저장위치가 0보다 크거나 같으면 존재하므로 등록오류  return false;
	 * 
	 * @param dto 등록 회원객체
	 * @return 등록 성공시 true, 등록 실패시 false 
	 */
	public boolean addMember(Member dto) {
		if (getIndex(dto.getMemberId()) == -1) {
			return list.add(dto);
		} 
		return false;
	}	
	
	public boolean addMember2(Member dto) {
		// 회원아이디가 존재하는지 비교해서
		int index = getIndex(dto.getMemberId());
		
		if (index == -1) {
			list.add(dto);
			System.out.println("[성공]" + dto.getMemberId() + "님 회원등록 성공하였습니다. 로그인 후 회원전용 서비스를 사용하세요.");
			return true;
		} else {
			System.out.println("[오류]" + dto.getMemberId() + "는 중복아이디로 사용 할 수 없습니다." );
			return false;			// 6
		}
	}
	
	public boolean addMember1(Member dto) {
		for (int index = 0; index < list.size(); index++) {	// 1
			Object obj = list.get(index);	// 2
			if (obj instanceof Member) {	// 3
				Member dto2 = (Member)obj;	// 4
				if (dto2.getMemberId().equals(dto.getMemberId())) {	// 5
					System.out.println("[오류]" + dto.getMemberId() + "는 중복아이디로 사용 할 수 없습니다." );
					return false;			// 6
				}
			}
		}
		
		list.add(dto);
		System.out.println("[성공]" + dto.getMemberId() + "님 회원등록 성공하였습니다. 로그인 후 회원전용 서비스를 사용하세요.");
		return true;
		
		//return list.add(dto);
	}
	
	/**
	 * 회원 상세 조회 메서드
	 * 
	 * 1. 저장된 회원의 크기만큼 반복하면서
	 * 2. 저장된 회원객체를 하나씩 가져와서 : 조회 : get(int) : Object
	 * 3. 가져온 객체가 Member의 인스턴스(객체)인지 비교해서 : instanceof
	 * 4. Member의 인스턴스이면 Member 타입으로 형변환 : (클래스이름)참조변수
	 * 5. 형변환한 회원객체의 아이디와 아규먼트로 전달받은 회원 아이디 getMemberId()가 같은지 비교해서 : equals()
	 * 
	 * 6. 아이디가 같으면 동일한 아이디가 존재하므로 현재 인덱스에 저장된 객체가 검색하는 객체이므로
	 * 	   형변환한 회원객체 반환 
	 * 
	 * 7. 반복을 다했는데도 반환되지 않았다면 동일한 아이디가 존재하지 않으므로 
	 * 	  return null 반환
	 * 
	 * @param memberId 조회회원아이디
	 * @return 존재하면 해당 회원객체, 존재하지 않으면 null
	 * @see getIndex(int)
	 */
	public Member getMember(String memberId) {
		int index = getIndex(memberId);
		if (index >= 0) {
			return (Member)list.get(index);
		}
		return null;
	}
	
	/**
	 * 회원 전체정보 변경 메서드
	 * 
	 * 1. 저장된 회원의 크기만큼 반복하면서
	 * 2. 저장된 회원객체를 하나씩 가져와서 : 조회 : get(int) : Object
	 * 3. 가져온 객체가 Member의 인스턴스(객체)인지 비교해서 : instanceof
	 * 4. Member의 인스턴스이면 Member 타입으로 형변환 : (클래스이름)참조변수
	 * 5. 형변환한 회원객체의 아이디와 아규먼트로 전달받은 회원객체의 아이디 getMemberId()가 같은지 비교해서 : equals()
	 * 
	 * 6. 아이디가 같으면 현재 인덱스에 저장된 객체가 변경해야하는 객체이므로 아규먼트로 전달받은 객체로 변경 : set(int, Object)
	 * 7. 변경 성공했으므로 return true 반환
	 * 
	 * 8. 반복을 다했는데도 반환되지 않았다면 동일한 아이디가 존재하지 않으므로 
	 * 	   변경 불가 오류 , return false 반환
	 * 
	 * @param dto 변경 회원객체
	 * @return 변경 성공시 true, 변경 실패시 false
	 */
	public boolean setMember(Member dto) {
		int index = getIndex(dto.getMemberId());
		if (index >= 0) {
			list.set(index, dto);
			return true;
		}
		return false;
	}
	
	/**
	 *  회원 삭제 메서드 : 아이디 존재하면 삭제
	 *  
	 * 1. 저장된 회원의 크기만큼 반복하면서
	 * 2. 저장된 회원객체를 하나씩 가져와서 : 조회 : get(int) : Object
	 * 3. 가져온 객체가 Member의 인스턴스(객체)인지 비교해서 : instanceof
	 * 4. Member의 인스턴스이면 Member 타입으로 형변환 : (클래스이름)참조변수
	 * 5. 형변환한 회원객체의 아이디와 아규먼트로 전달받은 회원객체의 아이디 getMemberId()가 같은지 비교해서 : equals()
	 * 
	 * 6. 아이디가 같으면 현재 인덱스에 저장된 객체가 삭제해야하는 객체이므로 해당 저장위치의 객체를 삭제 : remove(index)
	 * 7. 삭제 성공했으므로 return true 반환
	 * 
	 * 8. 반복을 다했는데도 반환되지 않았다면 동일한 아이디가 존재하지 않으므로 
	 * 	   삭제 불가 오류 , return false 반환
	 *  
	 * ## getIndex(String memberId) 메서드 사용시 처리 절차
	 * 1. 아규먼트로 전달받은 아이디가 존재하는지 비교해서
	 * 2. 저장위치가 0보다 크거나 같으면 
	 * 3. 해당 아이디 회원객체가 존재하므로 해당위치의 객체를 삭제하고 return true 반환
	 * 4. 저장위치가 0보다 작으면 해당 아이디 회원객체가 존재하지 않으므로 삭제불가, return false 반환
	 *   
	 * @param memberId 삭제할 회원 아이디
	 * @return 삭제 성공시 true, 삭제 실패시 false
	 */
	public boolean removeMember(String memberId) {
		int index = getIndex(memberId);	// 1
		if (index >= 0) {				// 2
			list.remove(index);			// 3
			return true;
		}
		return false;					// 4
	}
	
	/**
	 * 현재 등록한 전체회원
	 * @return 회원저장자료구조
	 */
	public ArrayList getMemberList() {
		return list;
	}
	
	/**
	 *  회원 삭제 메서드 : 아이디가 존재하면서 해당 회원의 비밀번호가 같으면 삭제
	 *  
	 * ## getIndex(String memberId) 메서드 사용시 처리 절차
	 * 1. 아규먼트로 전달받은 아이디가 존재하는지 비교해서
	 * 2. 저장위치가 0보다 크거나 같으면 
	 * 3. 해당 아이디 회원객체가 존재하므로 해당위치의 객체의 비밀번호와 아규먼트로 전달받은 비밀번호가 같은지 비교해서
	 * 4. 비밀번호 같으면 해당위치의 객체를  삭제하고 return true 반환
	 * 
	 * 5. 저장위치가 0보다 작으면 해당 아이디 회원객체가 존재하지 않으므로 삭제불가, 또는 아이디는 존재하지만 비밀번호가 틀려도 오류, return false 반환
	 * 
	 * @param memberId 삭제할 회원 아이디
	 * @param memberPw 삭제할 회원 비밀번호
	 * @return 삭제 성공시 true, 삭제 실패시 false
	 * @return
	 */
	public boolean removeMember(String memberId, String memberPw) {
		int index = getIndex(memberId);			// 1
		if (index >= 0) {						// 2
			Member dto = getMember(memberId);	// 3
			if (dto.getMemberPw().equals(memberPw)) {	// 3
				list.remove(index);				// 4
				return true;					// 4
			}
		}
		return false;	// 5. 회원아이디가 존재하지 않거나, 또는 비밀번호가 틀린 경우 
	}
	
	
	// 추가실습 : 비밀번호변경(아이디, 기존비밀번호, 변경비밀번호) : boolean
	
	// 추가실습 : 아이디찾기(이름,휴대폰) : 아이디
	// 추가실습 : 아이디찾기(이름,이메일) : 아이디
	
	// 추가실습 : 비밀번호찾기(아이디,이름,휴대폰) : 임시암호발급변경
	// 임시암호발급은 Utility에서 작성한 보안문자생성하기 호출 사용 : 과제구현활용
	
	// 추가실습 : 로그인(아이디, 비밀번호) : boolean
}







