package com.work.model.dto;

/**
 * <pre>
 * <b>회원 도메인 클래스</b>
 * 
 * 설계규칙 :
 * 1. encapsulation
 * 2. 생성자 중복정의
 * 4. equals() 메서드 재정의 : 회원 아이디
 * </pre>
 * 
 * @author 임경혜
 * @version ver.1.0
 * @see com.work.view.MemberTest
 *
 */
public class Member {
	/** 회원 아이디 정보 : 6자리 ~ 12자리 이내 */
	private String memberId = "guest";
	/** 회원 비밀번호 정보 : 6자리 ~ 20자리 이내 */
	private String memberPw;
	/** 이름 정보 */
	private String name;
	/** 휴대폰 정보 : 형식 010-1234-1234 */
	private String phone;
	/** 이메일 정보 */
	private String email;
	/** 가입일 정보 : 현재날짜 기본형식 년도4자리.월2자리.일2자리 */
	private String entryDate;
	private String grade;
	private int point;
	private String manager;
	
	/**
	 * 기본 생성자
	 */
	public Member() {
	}

	/**
	 * 필수데이터 초기화생성자 : 회원 등록시 회원 입력 정보
	 * @param memberId 아이디
	 * @param memberPw 비밀번호
	 * @param name 이름
	 * @param phone 휴대폰
	 * @param email 이메일
	 */
	public Member(String memberId, String memberPw, String name, String phone, String email) {
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.phone = phone;
		this.email = email;
	}

	public Member(String memberId, String memberPw, String name, String phone, String email, String entryDate,
			String grade, int point, String manager) {
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.entryDate = entryDate;
		this.grade = grade;
		this.point = point;
		this.manager = manager;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberPw() {
		return memberPw;
	}

	public void setMemberPw(String memberPw) {
		this.memberPw = memberPw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(memberId);
		builder.append(", ");
		builder.append(memberPw);
		builder.append(", ");
		builder.append(name);
		builder.append(", ");
		builder.append(phone);
		builder.append(", ");
		builder.append(email);
		builder.append(", ");
		builder.append(entryDate);
		builder.append(", ");
		builder.append(grade);
		builder.append(", ");
		builder.append(point);
		builder.append(", ");
		builder.append(manager);
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((memberId == null) ? 0 : memberId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Member other = (Member) obj;
		if (memberId == null) {
			if (other.memberId != null)
				return false;
		} else if (!memberId.equals(other.memberId))
			return false;
		return true;
	}

}


















