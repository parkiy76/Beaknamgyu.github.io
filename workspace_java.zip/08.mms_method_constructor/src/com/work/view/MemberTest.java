package com.work.view;

import com.work.model.dto.Member;

public class MemberTest {
	/** 생성자 테스트 */
	public static void main(String[] args) {
		Member dto1 = new Member();	// Member 클래스의 기본생성자 이용한 객체생성
		System.out.println(dto1.toString());
		System.out.println();
		
		// 아이디,비밀번호,이름,휴대폰,이메일 정보를 초기화 생성자 호출 수행
		Member dto2 = new Member("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com");
		System.out.println(dto2.toString());
		System.out.println();
		
		// 전체데이터 초기화 생성자 호출 수행
		Member dto3 = new Member("user01", "password01", "홍길동", "010-1234-1000", "user01@work.com", "2020.07.16", "G", 500, "없음");
		System.out.println(dto3.toString());
		System.out.println();
		
	}
	
	/* setter  메서드 테스트 */
	public static void main1(String[] args) {
		// 회원객체 선언 및 생성
		Member dto = new Member();
		
		// 생성한 회원객체의 속성정보를 본인정보로 변경
		dto.memberId = "khim98";
		dto.memberPw = "bluesky";
		dto.name = "임경혜";
		
		// 멤버변수 이용해서 휴대폰 변경
		//dto.phone = "010-2831-2773";
		
		// 멤버 메서드 이용해서 휴대폰 변경
		dto.setPhone("010-2831-2773");
		//dto.setPhone = "010-2831-2773";
		
		// 멤버변수 이용해서 이메일 변경
		//dto.email = "khim98@empal.com";
		
		// 멤버 메서드 이용해서 이메일 변경 :
		dto.setEmail("user01@work.com");
		
		dto.setName("홍길동");
		
	}

}









