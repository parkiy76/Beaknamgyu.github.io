package com.work.model.dto;

public class Member {
	public String memberId = "guest";
	public String memberPw;
	public String name;
	public String phone;
	public String email;
	public String entryDate;
	public String grade;
	public int point;
	public String manager;
	
	/** 기본생성자 */
	public Member() {
		//System.out.println("Member() 기본생성자 호출 수행됩니다.");
	}
	
	/** 회원등록시 필수 데이터 초기화 생성자 : 아이디, 비밀번호, 이름, 휴대폰, 이메일 */
	public Member(String memberId, String memberPw, String name, String phone, String email) {
		// 멤버변수 아이디 = 매개변수 아이디를 저장(초기화)
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.name = name;
		this.phone = phone;
		this.email = email;
		//System.out.println("### Member(아이디,비밀번호,이름,휴대폰,이메일) 초기화 생성자 호출 수행");
	}
	
	/** 실습: 회원의 전체데이터 초기화 생성자  : 아이디, 비밀번호, 이름, 휴대폰, 이메일  + 가입일, 등급, 포인트, 담당자 */
	public Member(String memberId, String memberPw, String name, String phone, String email, 
			String entryDate, String grade, int point, String manager) {
		// 전체데이터 초기화 수행문
//		this.memberId = memberId;
//		this.memberPw = memberPw;
//		this.name = name;
//		this.phone = phone;
//		this.email = email;
		
		this(memberId, memberPw, name, phone, email);	// 다른 생성자 먼저 수행

		this.entryDate = entryDate;
		this.grade = grade;
		this.point = point;
		this.manager = manager;
		
		//System.out.println("Member(아이디,비밀번호,이름,휴대폰,이메일,가입일,등급,포인트,담당자) 전체 데치터 초기화 생성자 호출 수행");
		
//		this(memberId, memberPw, name, phone, email); 	// 컴파일 오류 : 다른생성자 호출수행문은 생성자의 첫번째 수행문 위치
	}
	
	
	/* 실습1
	 * -- 아규먼트로 휴대폰 정보를 전달받아서 현재 휴대폰 번호를 변경하는 메서드
	 * -- 메서드명 규칙 : 변경하는 메서드 형식
	 * -- public void set멤버변수명(타입 매개변수명) { 기존멤버변수명 = 아규먼트로전달받은변경위한매개변수명; }
	 * -- 예시 : 휴대폰(phone)  변경 메서드 
	 */
	public void setPhone(String modifyPhone) {
		phone = modifyPhone;
	}
	
	/* 실습2 : 이메일 변경 메서드 구현 */
	public void setEmail(String modifyEmail) {
		email = modifyEmail;
	}
	
	public void setName(String modifyName) {
		name = modifyName;
	}

	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", memberPw=" + memberPw + ", name=" + name + ", phone=" + phone
				+ ", email=" + email + ", entryDate=" + entryDate + ", grade=" + grade + ", point=" + point
				+ ", manager=" + manager + "]";
	}
	
	
}















