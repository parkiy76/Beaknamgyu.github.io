package com.work.view;

public class GradeTest {

	public static void main(String[] args) {
		/* TODO : 요구사항 
		 * 
		 * 1. 	성적은 0 ~ 100점 이내
		 * 2. 	아래의 성적 범위에 따라 등급을 출력
		 * 		성적 90 ~ 100점 이면 등급은 A
		 * 		성적 80 ~ 89점 이면 등급은 B
		 * 		성적 70 ~ 79점 이면 등급은 C
		 * 		성적 60 ~ 69점 이면 등급은 D
		 * 		성적 0 ~ 59점 이면 등급은 F
		 * 
		 * 3. 출력형식:
		 * 		점수 : XX점
		 * 		등급 : A
		 * 
		 * 4. 만약, 성적이 0 ~ 100점에 해당 되지 않는 경우에는 오류 메세지 출력
		 * 		점수 : XX점
		 * 		[오류] 성적은 0 ~ 100점 이내로 입력하시기 바랍니다.
		 * 
		 * 5. if 구문 활용
		 * 
		 * 2. switch 구문 활용
		 */
		
		// 성적 변수 선언 및 할당	=> 배열, 메인메서드 아규먼트 전달(배열), 사용자입력(io), 임의의점수 api 사용(java.util.Random, java.lang.Math#random() )
		int score = 85;
		char grade = '\u0000';
		
		System.out.println("## if 구문 활용 :");
		
		if(score >= 0 && score <= 100) {
			if (score >= 90 && score <= 100) {
				grade = 'A';
			} else if(score >= 80 && score <= 89) {
				grade = 'B';
			} else if(score >= 70 && score <= 79) {
				grade = 'C';
			} else if(score >= 60 && score <= 69) {
				grade = 'D';
			} else {
				grade = 'F';
			}
			
			System.out.println("점수 : " + score);
			System.out.println("등급 : " + grade);
			
		} else {
			System.out.println("점수 : " + score);
			System.out.println("[오류] 성적은 0 ~ 100점 이내로 입력하시기 바랍니다.");		
		}
		
		System.out.println("\n\n ## switch 구문 활용 :");
		if(score >= 0 && score <= 100) {
			switch(score / 10) {
			case 10:
			case 9:
				grade = 'A';
				break;
			case 8:
				grade = 'B';
				break;
			case 7:
				grade = 'C';
				break;
			case 6:
				grade = 'D';
				break;
			default:
				grade = 'F';
			}
			
			System.out.println("점수 : " + score);
			System.out.println("등급 : " + grade);
			
		} else {
			System.out.println("점수 : " + score);
			System.out.println("[오류] 성적은 0 ~ 100점 이내로 입력하시기 바랍니다.");		
		}
		
		
//		System.out.println("점수 : " + score);
//		System.out.println("등급 : " + "A");
//		
//		System.out.println();
//		System.out.println("## switch 구문 활용 :");
//		System.out.println("점수 : " + score);
//		System.out.println("등급 : " + "A");
//		
//		score = 120;
//		System.out.println();
//		System.out.println("## if 구문 활용 :");
//		System.out.println("점수 : " + score);
//		System.out.println("[오류] 성적은 0 ~ 100점 이내로 입력하시기 바랍니다.");
//
//		System.out.println();
//		System.out.println("## switch 구문 활용 :");
//		System.out.println("점수 : " + score);
//		System.out.println("[오류] 성적은 0 ~ 100점 이내로 입력하시기 바랍니다.");

	}

}
