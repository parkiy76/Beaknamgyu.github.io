package com.work.view;

public class LoopTest {

	public static void main(String[] args) {
		// 실습1 : 1에서 10까지 출력해보세요
		// 실습2 : 1에서 10까지 누적한 덧셈결과를 출력해보세요
		// 실습3 : 1에서 10까지 짝수만 누적한 덧셈결과를 출력해보세요
		
		int no = 1; // 반복전에 초기화
		int sum = 0;
		
		while(no <= 10) {
			if (no % 2 == 0) {
				System.out.println(no);
				//no += 1;
				//sum += no;	// 로직 오류발생 결과 : 65
				
				//sum += no;
				//no += 1;		// 결과 : 55
				
				// 증감연산자 활용해서 변경해보세요
				//sum += no++; // 짝수만 덧셈출력시에는 오류발생 : 무한반복
				sum += no;
			} 
			
			no++;	// 반복후 1증가 로직
		}
		
//		while(no <= 10) {
//			if (no % 2 == 0) {
//				System.out.println(no);
//				//no += 1;
//				//sum += no;	// 로직 오류발생 결과 : 65
//				
//				//sum += no;
//				//no += 1;		// 결과 : 55
//				
//				// 증감연산자 활용해서 변경해보세요
//				sum += no++; // 짝수만 덧셈출력시에는 오류발생 : 무한반복
//			} else {
//				no++;
//			}
//		}

		System.out.println("sum = " + sum);
		
		// 실습4 : for 구문을 이용해서 1 ~ 10 사이의 3의 배수의 누적곱의 결과를 출력해보세요
		// 변수명 : sum, no 사용시 문제발생 ??
		int result = 1;		// 초기값 0, 1 결과??
		for (int index = 1; index <= 10; index++) {
			if (index % 3 == 0) {
				result *= index;
			}
		}
		
		System.out.println(); // 공백라인 출력
		System.out.println("1~10사이 3의배수 누적곱 결과 : " + result);
		
	}

}




















