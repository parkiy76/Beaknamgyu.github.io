package com.work.view;

public class GuGuDanTest {

	public static void main(String[] args) {
		/*
		 * ## 실습 : 구구단 출력
		 * -- 2단에서 9단까지 출력
		 * -- for 구문 활용, while 구문 활용, do~while 구문 활용
		 * -- 2단에서 9단까지
		 * 
		 * -- 짝수단 만 출력 : 반복문 본인 편한것으로 (for, while, do~while)
		 * -- 홀수 스템만 출력
		 * 
		 * -- 출력형식
		 * 
		 * 	# for 구구단
		 * 	2단 		3단		4단	....	9단
		 * 	2*1=2	3*1=3	4*1=4		9*1=9
		 * 	2*2=4
		 * 	2*3=6
		 * 	...
		 * 	2*9=18	3*9=27	4*9=36 ..	9*9=81
		 * 
		 */
		
		System.out.println("\n### for 구구단");
		printTitle(); // 구구단 제목행 출력 메서드 호출
		for (int step = 1; step <= 9; step++) {
			for (int dan = 2; dan <= 9; dan++) {
				System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
			}
			System.out.println();
		}
		
		System.out.println("\n### while 구구단");
		printTitle(); // 구구단 제목행 출력 메서드 호출
		// 초기화
		int step = 1;
		int dan = 2;
		
		while (step <= 9) {
			while (dan <= 9) {
				System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
				dan++;		// 단 1 증가
			}
			
			System.out.println();
			dan = 2;	// 단 초기화
			step++;		// step 1증가
		}
		
		step = 1;	// 스템 1 초기화
		dan = 2;	// 단 2 초기화
		
		System.out.println("\n### do~while 구구단");
		printTitle(); // 구구단 제목행 출력 메서드 호출
		do {
			do {
				System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
				dan++;		// 단 1 증가
			} while(dan <= 9);
			
			System.out.println();
			dan = 2;	// 단 초기화
			step++;		// step 1증가
		} while (step <= 9);
		
		System.out.println("\n### for 구구단 : 짝수단(2,4,6,8 단)");
		printTitle(true); // 구구단 짝수단 제목행 출력 메서드 호출
		for (step = 1; step <= 9; step++) {
			for (dan = 2; dan <= 9; dan++) {
				if (dan % 2 == 0) {
					System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
				}
			}
			System.out.println();
		}

		System.out.println("\n### for 구구단 : 짝수단(2,4,6,8 단) : continue 사용");
		printTitle(true); // 구구단 짝수단 제목행 출력 메서드 호출
		for (step = 1; step <= 9; step++) {
			for (dan = 2; dan <= 9; dan++) {
				if (dan % 2 != 0) {
					continue;
				}
				System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
			}
			System.out.println();
		}

		System.out.println("\n### for 구구단 : 홀수 스텝(1,3,5,7.9 스템)");
		printTitle(); // 구구단 제목행 출력 메서드 호출
		for (step = 1; step <= 9; step++) {
			if (step % 2 == 1) {
				for (dan = 2; dan <= 9; dan++) {
					System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
				}
				System.out.println();
			}
		}
		
		System.out.println("\n### for 구구단 : 홀수 스텝(1,3,5,7.9 스템) : continue 사용");
		printTitle(); // 구구단 제목행 출력 메서드 호출
		for (step = 1; step <= 9; step++) {
			if (step % 2 != 1) {
				continue;
			}
			
			for (dan = 2; dan <= 9; dan++) {
				System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
			}
			System.out.println();
		}
		
		System.out.println("\n### for 구구단 : 홀수단(3,5,7,9 단) : continue 사용");
		printTitle(false); // 구구단 홀수단 제목행 출력 메서드 호출
		for (step = 1; step <= 9; step++) {
			for (dan = 2; dan <= 9; dan++) {
				if (dan % 2 == 0) {
					continue;
				}
				System.out.print(dan + "*" + step + "=" + (dan * step) + "\t");
			}
			System.out.println();
		}
	}
	
	/** 객체생성없이 사용하기 위한 구구단 제목행을 출력하는 클래스 메서드 */
	public static void printTitle() {
		for (int dan = 2; dan <= 9; dan++) {
			System.out.print(dan + "단" + "\t");
		}
		System.out.println();
	}

	/** 객체생성없이 사용하기 위한 구구단 제목행을 출력하는 클래스 메서드 
	 *  아규먼트가 true이면 짝수단 제목 출력, false이면 홀수단 제목 출력
	 * @param isEven
	 */
	public static void printTitle(boolean isEven) {
		for (int dan = 2; dan <= 9; dan++) {
			if (isEven) {
				if (dan % 2 == 0) {
					System.out.print(dan + "단" + "\t");
				}
			} else {
				if (dan % 2 == 1) {
					System.out.print(dan + "단" + "\t");
				}
			}
		}
		System.out.println();
	}
}


